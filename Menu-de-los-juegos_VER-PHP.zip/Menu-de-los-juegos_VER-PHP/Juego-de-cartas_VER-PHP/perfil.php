<?php
$usuario_actual = "MILO";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil de Usuario - Mailo</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style-memoria.css">
</head>
<body>

    <div class="pantalla-principal">
        
        <div class="contenido-izquierdo-juego">
            <header class="encabezado">
                <div class="logo-mailo">
                    <span>🐶 MAILO</span>
                </div>
                <h1 class="titulo-principal">Perfil de <?php echo $usuario_actual; ?></h1>
            </header>

            <main class="zona-perfil">
                <h2 class="subtitulo-seccion">🏆 Trofeos y Logros</h2>
                
                <div class="grid-trofeos">
                    <div class="tarjeta-trofeo bloqueado" id="trofeo-flash">
                        <div class="icono-trofeo">⚡</div>
                        <div class="info-trofeo">
                            <h3>Rayo Flash</h3>
                            <p>Completa el juego de memoria en menos de 1 minuto.</p>
                        </div>
                    </div>

                    <div class="tarjeta-trofeo bloqueado" id="trofeo-promedio">
                        <div class="icono-trofeo">⚙️</div>
                        <div class="info-trofeo">
                            <h3>Constante y Seguro</h3>
                            <p>Completa el juego de memoria en menos de 2:30 minutos.</p>
                        </div>
                    </div>

                    <div class="tarjeta-trofeo bloqueado" id="trofeo-tortuga">
                        <div class="icono-trofeo">🐢</div>
                        <div class="info-trofeo">
                            <h3>Sin Prisa pero Sin Pausa</h3>
                            <p>Completa el juego de memoria en más de 2:30 minutos.</p>
                        </div>
                    </div>
                </div>
            </main>

            <footer class="pie-pagina">
                <p>DESCUBRE 'RUTA DE COLORES' HOY - DISPONIBLE EN www.mailoa.com</p>
            </footer>
        </div>

        <?php include 'sidebar.php'; ?>

    </div>

    <script>
        // Carga el estado de los trofeos desde localStorage
        document.addEventListener('DOMContentLoaded', () => {
            const trofeosObtenidos = JSON.parse(localStorage.getItem('trofeos_mailo')) || [];

            trofeosObtenidos.forEach(idTrofeo => {
                const el = document.getElementById(idTrofeo);
                if (el) {
                    el.classList.remove('bloqueado');
                    el.classList.add('desbloqueado');
                }
            });
        });
    </script>
</body>
</html>